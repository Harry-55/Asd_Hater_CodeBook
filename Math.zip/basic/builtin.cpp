__builtin_popcountll // 二 進 位 有 幾 個1 (記 得 這 是long long)
__builtin_clzll // 左 起 第 一 個1之 前0的 個 數
__builtin_parityll // 1的 個 數 的 奇 偶 性
__builtin_mul_overflow(a,b,&h) // a*b是 否 溢位,h = a * b
__builtin_add_overflow(a,b,&h)